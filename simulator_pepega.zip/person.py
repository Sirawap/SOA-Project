class Person:
    def __init__(self,x,y,id):
        self.x = x
        self.y = y
        self.id = id
